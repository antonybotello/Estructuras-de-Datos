package com.usta;

import java.util.Stack;
import java.util.LinkedList;
import java.util.Queue;

public class Main {
    public static void main(String[] args) {
        
        Stack<Integer> pila = new Stack<>();
        Queue<String> cola = new LinkedList<>();

        
        pila.push(4);
        pila.push(2);
        pila.push(0);
        pila.push(-1);

        int elementoCima = pila.peek();
        System.out.println("El elemento de la cima de la pila: " + elementoCima);

        int elementoEliminadoPila = pila.pop();
        System.out.println("El elemento eliminado de la pila: " + elementoEliminadoPila);

        boolean estaVacia = pila.isEmpty();
        System.out.println("¿La pila está vacía? " + estaVacia);

        
        
        int capacidadPila = getCapacity(pila);
        System.out.println("Capacidad actual de la pila: " + capacidadPila);

        System.out.println("Índice de 0 en la pila: " + pila.search(0));
        System.out.println("Índice de 22 en la pila: " + pila.search(22));

        System.out.println("#################################################");

        
        cola.offer("Elemento1");
        cola.offer("Elemento2");
        cola.offer("Elemento3");

        String elementoFrente = cola.peek();
        System.out.println("El elemento en el frente de la cola: " + elementoFrente);

        String elementoEliminadoCola = cola.poll();
        System.out.println("El elemento eliminado de la cola: " + elementoEliminadoCola);

        boolean estaVaciaCola = cola.isEmpty();
        System.out.println("¿La cola está vacía? " + estaVaciaCola);
    }

    
    private static int getCapacity(Stack<?> stack) {
        try {
           
            java.lang.reflect.Field field = java.util.Vector.class.getDeclaredField("elementData");
            field.setAccessible(true);
            Object[] elementData = (Object[]) field.get(stack);
            return elementData.length;
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
        return -1; 
    }
}


